<?php
  function getSummary($fname, $lname, $age, $occupation, $byear) {
    return "$fname $lname, $age, $occupation, born in $byear.";
  }
?>
